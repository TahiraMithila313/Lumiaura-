# Lumiaura

Lumiaura is an open-source Android manga-reader project with a luminous, professional dark interface.

The project is a clean-room implementation. Visual ideas can be inspired by existing manga-reader UX patterns, but proprietary assets and code are not copied.

## Current MVP

- Jetpack Compose + Material 3
- Home
- Library
- Discover
- History
- Settings
- Manga model/demo catalog
- Comic detail page
- No-blur cover background treatment
- Chapter list
- **Recommendations**
  - Story
  - Genre
  - Reader Match
- Horizontal recommendation carousel
- Reader screen scaffold
- Room dependency prepared
- Extension/source placeholder
- Downloads/storage placeholder
- Backup/restore placeholder
- Lumiaura Icon Studio placeholder

## GitHub Actions

The repository includes:

`.github/workflows/build-apk.yml`

Every push and pull request builds a debug APK automatically.

To download it:

1. Open your GitHub repository.
2. Select **Actions**.
3. Open **Build Lumiaura APK**.
4. Open the completed workflow run.
5. Scroll to **Artifacts**.
6. Download **Lumiaura-debug-apk**.
7. Extract it and install `app-debug.apk` on Android.

A manually triggered release workflow is also included at:

`.github/workflows/release.yml`

It currently builds an unsigned release APK. Production distribution should use a private signing key stored in GitHub Actions Secrets.

## Local build

Requirements:

- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35

Then:

```bash
./gradlew :app:assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Repository structure

```text
Lumiaura/
├── .github/
│   └── workflows/
│       ├── build-apk.yml
│       └── release.yml
├── app/
│   ├── build.gradle.kts
│   └── src/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew
├── gradlew.bat
├── LICENSE
└── README.md
```

## Roadmap

The next implementation stages are:

1. Real Room entities/DAOs/repositories
2. Persistent library/history/settings
3. Source/extension interface
4. Real source adapters
5. Search and manga metadata loading
6. Chapter/page loading
7. Webtoon + paged reader
8. LTR/RTL and pinch zoom
9. Download manager + offline reader
10. Backup/restore
11. Recommendation engine
12. Icon Studio with gallery image crop/zoom and launcher icon switching
13. Release signing and Play-ready builds

Anything not implemented yet is intentionally shown as an MVP placeholder in the app rather than represented as functional.
