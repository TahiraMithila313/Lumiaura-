# Lumiaura — no-personal-license-acceptance build setup

This package deliberately does **not** contain a step that asks the repository owner to accept Android SDK licenses.

The GitHub Actions build uses the Android SDK components already present on GitHub-hosted Ubuntu runners. It does **not** run `sdkmanager --licenses`, `yes | sdkmanager --licenses`, or install Android SDK packages during the workflow.

## Important distinction

This is a technical build configuration, not a legal opinion. It avoids an explicit license-acceptance action in your repository and avoids asking you to click/confirm a license in the workflow. The Android SDK itself is still third-party software, and its terms can apply to use of the SDK. Read the current terms if you need legal certainty.

The workflow is intentionally configured to fail if the preinstalled Android SDK required by the project is unavailable, rather than silently accepting or installing SDK licenses.
