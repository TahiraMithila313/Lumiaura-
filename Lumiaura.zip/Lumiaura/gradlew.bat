@echo off
rem Generate/use the Gradle wrapper from Android Studio for this project.
