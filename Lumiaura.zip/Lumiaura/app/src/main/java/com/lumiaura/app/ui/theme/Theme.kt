package com.lumiaura.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LumiaPurple = Color(0xFFB95CFF)
private val LumiaPink = Color(0xFFFF5CCB)
private val LumiaBlue = Color(0xFF6B7CFF)
private val LumiaBg = Color(0xFF090A14)
private val LumiaSurface = Color(0xFF121326)

private val DarkColors = darkColorScheme(
    primary = LumiaPink,
    secondary = LumiaPurple,
    tertiary = LumiaBlue,
    background = LumiaBg,
    surface = LumiaSurface,
    onBackground = Color(0xFFF4F0FA),
    onSurface = Color(0xFFF4F0FA)
)

@Composable
fun LumiauraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
