package com.lumiaura.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.lumiaura.app.data.DemoCatalog
import com.lumiaura.app.data.Manga

private val Pink = Color(0xFFFF5CCB)
private val Purple = Color(0xFFB95CFF)
private val Blue = Color(0xFF6B7CFF)

@Composable
fun LumiauraApp() {
    val nav = rememberNavController()
    var selected by remember { mutableStateOf("home") }

    Scaffold(
        containerColor = Color(0xFF090A14),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0E0F1C)) {
                listOf(
                    Triple("home", "Home", Icons.Default.Home),
                    Triple("library", "Library", Icons.Default.CollectionsBookmark),
                    Triple("discover", "Discover", Icons.Default.Explore),
                    Triple("history", "History", Icons.Default.History),
                    Triple("settings", "Settings", Icons.Default.Settings)
                ).forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = selected == route,
                        onClick = { selected = route; nav.navigate(route) },
                        icon = { Icon(icon, label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen { nav.navigate("detail/${it.id}") } }
            composable("library") { LibraryScreen { nav.navigate("detail/${it.id}") } }
            composable("discover") { DiscoverScreen { nav.navigate("detail/${it.id}") } }
            composable("history") { HistoryScreen { nav.navigate("reader/${it.id}") } }
            composable("settings") { SettingsScreen() }
            composable("detail/{id}") { back ->
                val id = back.arguments?.getString("id")?.toLongOrNull() ?: 1
                DetailScreen(DemoCatalog.manga.first { it.id == id }, onBack = { nav.popBackStack() }, onRead = { nav.navigate("reader/$id") })
            }
            composable("reader/{id}") { back ->
                val id = back.arguments?.getString("id")?.toLongOrNull() ?: 1
                ReaderScreen(DemoCatalog.manga.first { it.id == id }, onBack = { nav.popBackStack() })
            }
        }
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        subtitle?.let { Text(it, color = Color(0xFFAAA9BA), modifier = Modifier.padding(top = 4.dp)) }
    }
}

@Composable
private fun MangaCard(m: Manga, onClick: () -> Unit) {
    Column(
        Modifier.width(145.dp).clickable(onClick = onClick)
    ) {
        Box(
            Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Purple, Blue, Color(0xFF1A1830))))
        ) {
            Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                Text(m.title, fontWeight = FontWeight.Bold, maxLines = 2)
                Text("${m.rating} ★  •  ${m.chapters} ch", style = MaterialTheme.typography.labelSmall)
            }
            Text(m.status, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                .background(Color.Black.copy(alpha = .45f), RoundedCornerShape(8.dp)).padding(horizontal = 7.dp, vertical = 4.dp),
                style = MaterialTheme.typography.labelSmall)
        }
        Text(m.genres.take(2).joinToString(" • "), color = Color(0xFFB9B7C7), style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 7.dp))
    }
}

@Composable
private fun Section(title: String, items: List<Manga>, onClick: (Manga) -> Unit) {
    Column(Modifier.padding(bottom = 24.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            TextButton(onClick = {}) { Text("See more") }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items.take(7)) { MangaCard(it, { onClick(it) }) }
        }
    }
}

@Composable
private fun HomeScreen(open: (Manga) -> Unit) {
    LazyColumn {
        item { PageTitle("Lumiaura", "A luminous home for your manga library") }
        item { Section("Continue Reading", DemoCatalog.manga.filter { it.progress > 0 }, open) }
        item { Section("Featured", DemoCatalog.manga, open) }
        item { Section("Latest Updates", DemoCatalog.manga.reversed(), open) }
        item { Section("Popular", DemoCatalog.manga.sortedByDescending { it.rating }, open) }
    }
}

@Composable
private fun LibraryScreen(open: (Manga) -> Unit) {
    LazyColumn {
        item { PageTitle("Library", "Your saved manga") }
        item {
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(true, {}, { Text("All") })
                FilterChip(false, {}, { Text("Unread") })
                FilterChip(false, {}, { Text("Ongoing") })
            }
        }
        item {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.height(650.dp).padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(DemoCatalog.manga) { MangaCard(it, { open(it) }) }
            }
        }
    }
}

@Composable
private fun DiscoverScreen(open: (Manga) -> Unit) {
    LazyColumn {
        item { PageTitle("Discover", "Search sources, genres and new releases") }
        item {
            OutlinedTextField(value = "", onValueChange = {}, placeholder = { Text("Search manga…") },
                leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp))
        }
        item { Section("Popular", DemoCatalog.manga, open) }
        item { Section("Latest", DemoCatalog.manga.reversed(), open) }
        item { Section("Genres", DemoCatalog.manga.filter { it.genres.contains("Fantasy") }, open) }
        item {
            Card(Modifier.padding(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF151529))) {
                Column(Modifier.padding(18.dp)) {
                    Text("Extensions", fontWeight = FontWeight.Bold)
                    Text("MVP placeholder: extension/source management architecture will connect here.",
                        color = Color(0xFFAAA9BA), modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(open: (Manga) -> Unit) {
    LazyColumn {
        item { PageTitle("History", "Resume where you left off") }
        items(DemoCatalog.manga.filter { it.progress > 0 }) { m ->
            ListItem(
                headlineContent = { Text(m.title) },
                supportingContent = { Text("Chapter ${m.progress} of ${m.chapters}") },
                leadingContent = { Box(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(Brush.linearGradient(listOf(Pink, Purple)))) },
                trailingContent = { Text("${m.progress}/${m.chapters}") },
                modifier = Modifier.clickable { open(m) }
            )
        }
    }
}

@Composable
private fun SettingsScreen() {
    LazyColumn {
        item { PageTitle("Settings", "Customize Lumiaura") }
        item { SettingsGroup("Appearance", listOf("Theme", "Home customization", "Library display", "Categories")) }
        item { SettingsGroup("Reader", listOf("Reading direction", "Webtoon / paged mode", "Zoom & gestures", "Progress display")) }
        item { SettingsGroup("Downloads", listOf("Offline chapters", "Download queue", "Storage management")) }
        item { SettingsGroup("Backup & Restore", listOf("Local backup", "Restore backup")) }
        item { SettingsGroup("Extensions", listOf("Sources", "Community extensions")) }
        item {
            Card(Modifier.padding(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF17152A))) {
                Column(Modifier.padding(18.dp)) {
                    Text("Lumiaura Icon Studio", fontWeight = FontWeight.Bold)
                    Text("MVP placeholder: built-in variants + gallery image crop/zoom + apply/reset will be implemented here.",
                        color = Color(0xFFAAA9BA), modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun SettingsGroup(title: String, rows: List<String>) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, color = Pink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        rows.forEach { row ->
            ListItem(headlineContent = { Text(row) }, trailingContent = { Icon(Icons.Default.ChevronRight, null) })
        }
    }
}

@Composable
private fun DetailScreen(m: Manga, onBack: () -> Unit, onRead: () -> Unit) {
    LazyColumn {
        item {
            Box(
                Modifier.fillMaxWidth().height(330.dp)
                    .background(Brush.verticalGradient(listOf(Purple.copy(alpha=.65f), Blue.copy(alpha=.28f), Color(0xFF090A14))))
            ) {
                IconButton(onClick = onBack, modifier = Modifier.padding(top = 24.dp, start = 8.dp)) { Icon(Icons.Default.ArrowBack, "Back") }
                Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    Text(m.title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("${m.rating} ★  •  ${m.chapters} chapters  •  ${m.status}", color = Color.White.copy(.82f))
                }
            }
        }
        item {
            Column(Modifier.padding(20.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    m.genres.forEach { AssistChip(onClick = {}, label = { Text(it) }) }
                }
                Text(m.summary, color = Color(0xFFC8C6D2), modifier = Modifier.padding(top = 18.dp))
                Text("Updated: ${m.updateDay}  •  Source: ${m.source}", color = Color(0xFFAAA9BA), modifier = Modifier.padding(top = 12.dp))
                Button(onClick = onRead, modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) { Text("Start / Continue Reading") }
            }
        }
        item {
            Text("Chapters", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        }
        items((1..minOf(m.chapters, 8)).toList().reversed()) { ch ->
            ListItem(
                headlineContent = { Text("Chapter $ch") },
                supportingContent = { Text(if (ch <= m.progress) "Read" else "Unread") },
                trailingContent = { Icon(Icons.Default.ChevronRight, null) }
            )
        }
        item {
            Text("Recommendations", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(20.dp, 24.dp, 20.dp, 8.dp))
        }
        item { RecommendationModes(m, onClick = {}) }
    }
}

@Composable
private fun RecommendationModes(m: Manga, onClick: (Manga) -> Unit) {
    var mode by remember { mutableStateOf("Story") }
    val modes = listOf("Story", "Genre", "Reader Match")
    Column {
        TabRow(selectedTabIndex = modes.indexOf(mode), containerColor = Color.Transparent) {
            modes.forEach { label ->
                Tab(selected = mode == label, onClick = { mode = label }, text = { Text(label) })
            }
        }
        val items = when (mode) {
            "Genre" -> DemoCatalog.manga.filter { it.genres.any(m.genres::contains) }
            "Reader Match" -> DemoCatalog.manga.sortedByDescending { it.rating }
            else -> DemoCatalog.manga.reversed()
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items.take(7)) { MangaCard(it, { onClick(it) }) }
            item { TextButton(onClick = {}) { Text("See more") } }
        }
    }
}

@Composable
private fun ReaderScreen(m: Manga, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(top = 28.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.Close, "Close") }
            Text(m.title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Text("Ch. ${m.progress.coerceAtLeast(1)}")
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF1C1730), Color(0xFF0D0D18))))) {
            Column(Modifier.align(Alignment.Center).padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.MenuBook, null, modifier = Modifier.size(64.dp), tint = Pink)
                Text("Reader canvas", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 12.dp))
                Text("MVP placeholder: connect page images, vertical webtoon mode, LTR/RTL, pinch zoom, retry and offline pages.",
                    color = Color(0xFFAAA9BA), modifier = Modifier.padding(top = 8.dp))
            }
        }
        LinearProgressIndicator(progress = { m.progress.toFloat() / m.chapters.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth())
    }
}
