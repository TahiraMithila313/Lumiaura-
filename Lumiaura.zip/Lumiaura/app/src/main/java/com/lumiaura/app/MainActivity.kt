package com.lumiaura.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import com.lumiaura.app.ui.LumiauraApp
import com.lumiaura.app.ui.theme.LumiauraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LumiauraTheme {
                Surface { LumiauraApp() }
            }
        }
    }
}
