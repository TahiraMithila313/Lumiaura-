package com.lumiaura.app.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "library")
data class LibraryEntity(
    @PrimaryKey val mangaId: Long,
    val title: String,
    val lastChapter: Int,
    val progress: Int
)

@Database(entities = [LibraryEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase()
