package com.lumiaura.app.data

data class Manga(
    val id: Long,
    val title: String,
    val coverUrl: String,
    val summary: String,
    val genres: List<String>,
    val status: String,
    val rating: Double,
    val chapters: Int,
    val source: String,
    val updateDay: String,
    val progress: Int = 0
)

object DemoCatalog {
    val manga = listOf(
        Manga(1, "Lunar Veil", "", "A quiet city hides a luminous secret beneath its midnight streets.", listOf("Fantasy", "Mystery", "Drama"), "Ongoing", 4.8, 86, "Lumia Source", "Friday", 32),
        Manga(2, "Glass Garden", "", "Two strangers discover a garden that remembers every story ever told.", listOf("Romance", "Fantasy", "Drama"), "Ongoing", 4.6, 54, "Moonlight", "Tuesday", 0),
        Manga(3, "Neon Eclipse", "", "A courier crosses a futuristic city where memories can be traded.", listOf("Action", "Sci-Fi", "Mystery"), "Ongoing", 4.7, 121, "Aurora", "Sunday", 74),
        Manga(4, "Paper Moon", "", "A slice-of-life story about art, friendship and second chances.", listOf("Drama", "Slice of Life", "Romance"), "Completed", 4.5, 48, "Koma", "—", 48),
        Manga(5, "Starless Sea", "", "A diver follows a constellation beneath an impossible ocean.", listOf("Adventure", "Fantasy", "Drama"), "Ongoing", 4.9, 63, "Moonlight", "Thursday", 12),
        Manga(6, "Velvet Signal", "", "A radio host starts receiving broadcasts from tomorrow.", listOf("Mystery", "Sci-Fi", "Drama"), "Ongoing", 4.4, 39, "Aurora", "Monday", 0),
        Manga(7, "Ember Archive", "", "A librarian protects a forbidden archive of living stories.", listOf("Fantasy", "Adventure", "Mystery"), "Ongoing", 4.7, 72, "Koma", "Saturday", 0),
        Manga(8, "Blue Hour", "", "A gentle romance unfolding during the last hour before sunrise.", listOf("Romance", "Drama"), "Completed", 4.6, 36, "Lumia Source", "—", 36)
    )
}
